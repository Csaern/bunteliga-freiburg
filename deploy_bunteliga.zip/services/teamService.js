const admin = require('firebase-admin');
const db = admin.firestore();
const teamsCollection = db.collection('teams');
const seasonsCollection = db.collection('seasons');
const resultsCollection = db.collection('results');
const bookingsCollection = db.collection('bookings');
const Team = require('../models/team');
const seasonService = require('./seasonService');
const bookingService = require('./bookingService');

async function getTeamById(teamId) {
  const doc = await teamsCollection.doc(teamId).get();
  if (!doc.exists) {
    throw new Error('Team nicht gefunden.');
  }
  return { id: doc.id, ...doc.data() };
}

/**
 * Ruft alle Teams aus der Datenbank ab, sortiert nach Namen.
 */
async function getAllTeams() {
  const snapshot = await teamsCollection.orderBy('name').get();
  if (snapshot.empty) return [];
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

async function createTeam(teamData) {
  const newTeam = new Team(teamData);
  const firestoreObject = newTeam.toFirestoreObject();

  firestoreObject.createdAt = admin.firestore.FieldValue.serverTimestamp();
  firestoreObject.updatedAt = admin.firestore.FieldValue.serverTimestamp();

  const docRef = await teamsCollection.add(firestoreObject);
  return { id: docRef.id, ...firestoreObject };
}

/**
 * KORREKTUR: Dies ist jetzt die einzige Update-Funktion.
 * Sie aktualisiert die Team-Details und propagiert Namensänderungen in Saisons, Ergebnisse UND Buchungen.
 * @param {string} teamId - Die ID des zu aktualisierenden Teams.
 * @param {object} updates - Die zu aktualisierenden Daten.
 * @returns {object} Eine Erfolgsnachricht.
 */
async function updateTeam(teamId, updates) {
  const teamRef = teamsCollection.doc(teamId);
  const docBefore = await teamRef.get();
  if (!docBefore.exists) {
    throw new Error('Team nicht gefunden.');
  }
  const oldName = docBefore.data().name;
  const newName = updates.name;

  // 1. Das Haupt-Teamdokument aktualisieren
  const allowedUpdates = { ...updates };
  delete allowedUpdates.createdBy;
  delete allowedUpdates.captains;
  allowedUpdates.updatedAt = admin.firestore.FieldValue.serverTimestamp();
  await teamRef.update(allowedUpdates);

  // 2. Wenn der Name geändert wurde, die Änderung in alle abhängigen Dokumente propagieren
  if (newName && newName !== oldName) {
    const batch = db.batch();

    // --- A) Saisons aktualisieren ---
    const seasonsSnapshot = await seasonsCollection.get();
    seasonsSnapshot.forEach(doc => {
      const seasonData = doc.data();
      let needsUpdate = false;
      const updatedTeamsArray = seasonData.teams.map(team => {
        if (team.id === teamId && team.name !== newName) {
          needsUpdate = true;
          return { ...team, name: newName };
        }
        return team;
      });
      if (needsUpdate) {
        batch.update(doc.ref, { teams: updatedTeamsArray });
      }
    });

    // --- B) Ergebnisse aktualisieren ---
    const resultsAsHomeQuery = resultsCollection.where('homeTeamId', '==', teamId).get();
    const resultsAsAwayQuery = resultsCollection.where('awayTeamId', '==', teamId).get();
    const [homeResultsSnapshot, awayResultsSnapshot] = await Promise.all([resultsAsHomeQuery, resultsAsAwayQuery]);
    homeResultsSnapshot.forEach(doc => batch.update(doc.ref, { homeTeamName: newName }));
    awayResultsSnapshot.forEach(doc => batch.update(doc.ref, { awayTeamName: newName }));

    // --- C) Buchungen aktualisieren (NEUE LOGIK) ---
    const bookingsQuery = await bookingsCollection.where('teamId', '==', teamId).get();
    bookingsQuery.forEach(doc => {
      batch.update(doc.ref, { teamName: newName });
    });

    // 3. Führe alle gesammelten Updates auf einmal aus
    await batch.commit();
  }

  // KORREKTUR: Das vollständige, aktualisierte Dokument abrufen und zurückgeben
  const updatedDoc = await teamRef.get();
  return { id: updatedDoc.id, ...updatedDoc.data() };
}


/**
 * Aktualisiert nur den Logo-Pfad eines Teams und gibt das vollständige, aktualisierte Team-Objekt zurück.
 * @param {string} teamId - Die ID des Teams.
 * @param {string} logoPath - Der relative Pfad zum neuen Logo.
 * @returns {object} Das aktualisierte Team-Objekt.
 */
async function updateTeamLogo(teamId, logoPath, logoType = 'dark') {
  const teamRef = teamsCollection.doc(teamId);
  const doc = await teamRef.get();

  if (!doc.exists) {
    throw new Error('Team nicht gefunden.');
  }

  // Hier könnten wir das alte Logo vom Server löschen, wenn eines existiert.
  // const oldLogoPath = doc.data().logoUrl;
  // if (oldLogoPath) { ... fs.unlink ... }

  const updateData = {
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  };

  if (logoType === 'light') {
    updateData.logoUrlLight = logoPath;
  } else {
    updateData.logoUrl = logoPath;
  }

  await teamRef.update(updateData);

  const updatedDoc = await teamRef.get();
  return { id: updatedDoc.id, ...updatedDoc.data() };
}

async function deleteTeam(teamId) {
  await teamsCollection.doc(teamId).delete();
  return { message: 'Team erfolgreich gelöscht.' };
}

// Dummy-Funktion, falls sie an anderer Stelle benötigt wird
async function getTeamsByIds(ids) {
  if (!ids || ids.length === 0) return [];
  const snapshot = await teamsCollection.where(admin.firestore.FieldPath.documentId(), 'in', ids).get();
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

/**
 * KORREKTUR: Diese Funktion ist jetzt eine eigenständige, exportierte Funktion.
 * Sie ruft Teams ab, die zu einer bestimmten Saison gehören.
 */
async function getTeamsForSeason(seasonId) {
  if (!seasonId) {
    throw new Error('Eine Saison-ID ist erforderlich.');
  }

  const seasonData = await seasonService.getSeasonById(seasonId);
  if (!seasonData) {
    console.warn(`Saison mit ID ${seasonId} nicht gefunden.`);
    return [];
  }

  if (!seasonData.teams || seasonData.teams.length === 0) {
    return [];
  }

  const teamIds = seasonData.teams.map(t => t.teamId);

  if (teamIds.length === 0) {
    return [];
  }

  const teamsSnapshot = await teamsCollection.where(admin.firestore.FieldPath.documentId(), 'in', teamIds).get();

  const teams = teamsSnapshot.docs.map(doc => {
    const teamData = doc.data();
    const seasonTeamInfo = seasonData.teams.find(t => t.teamId === doc.id);
    return {
      id: doc.id,
      ...teamData,
      status: seasonTeamInfo ? seasonTeamInfo.status : 'unknown'
    };
  });

  return teams;
}

/**
 * KORREKTUR: Diese Funktion wird jetzt komplett eigenständig und robuster.
 * Sie holt die aktive Saison und verarbeitet deren Team-IDs direkt,
 * um den "undefined" Fehler endgültig zu verhindern.
 */
async function getTeamsForActiveSeason() {
  // 1. Finde die aktive Saison
  const activeSeason = await seasonService.getActiveSeason();

  // 2. Prüfe, ob Teams in der Saison vorhanden sind
  if (!activeSeason.teams || activeSeason.teams.length === 0) {
    return [];
  }

  // 3. KORREKTUR: Extrahiere die Team-IDs aus dem korrekten Feld `id` (statt `teamId`)
  const teamIds = activeSeason.teams
    .map(t => t.id) // Hier war der Fehler!
    .filter(id => id);

  if (teamIds.length === 0) {
    return [];
  }

  // 4. Rufe die Team-Dokumente ab
  const teamsSnapshot = await teamsCollection.where(admin.firestore.FieldPath.documentId(), 'in', teamIds).get();

  // 5. KORREKTUR: Gib die reinen Team-Daten zurück, ohne den überflüssigen Status
  const teams = teamsSnapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
  }));

  return teams;
}

/**
 * NEU: Ermittelt alle potenziellen Gegner für ein Team in der aktiven Saison.
 * Berücksichtigt Saisonmodus, gespielte Ergebnisse und zukünftige Buchungen.
 */
async function getPotentialOpponents(teamId, isFriendly = false) {
  const activeSeason = await seasonService.getActiveSeason();
  if (!activeSeason || !activeSeason.teams || activeSeason.teams.length === 0) return [];

  const seasonTeamIds = activeSeason.teams.map(t => t.id).filter(id => id);

  // NEU: Wenn es ein Freundschaftsspiel ist, geben wir alle anderen Teams zurück.
  if (isFriendly) {
    const allSeasonTeams = await getTeamsByIds(seasonTeamIds);
    return allSeasonTeams.filter(t => t.id !== teamId);
  }

  const [allSeasonTeams, seasonResults, allPitches, seasonBookingsSnapshot] = await Promise.all([
    getTeamsByIds(seasonTeamIds),
    resultsCollection.where('seasonId', '==', activeSeason.id).get(),
    db.collection('pitches').get(),
    bookingsCollection.where('seasonId', '==', activeSeason.id).get(),
  ]);

  const pitchesData = allPitches.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  const resultsData = seasonResults.docs.map(doc => doc.data());

  // Alle Buchungen der Saison
  const seasonBookings = seasonBookingsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

  // Set von Booking-IDs, für die bereits ein Ergebnis existiert
  const bookingsWithResults = new Set(resultsData.map(r => r.bookingId).filter(id => id));

  // Nur Liga-Ergebnisse (keine Freundschaftsspiele) für die Wertung der Paarungen zählen
  // Wir zählen hier nur Ergebnisse, die NICHT mit einer Buchung verknüpft sind (Legacy oder manuell),
  // ODER Ergebnisse, deren Buchung wir kennen und die nicht friendly ist.
  // Einfacher: Wir zählen alle Ergebnisse, die als Ligaspiel gewertet werden.
  // Da wir 'gamesPlayed' unten berechnen, müssen wir aufpassen, nicht doppelt zu zählen.
  // Strategie: 
  // 1. Zähle alle Ergebnisse (League Results).
  // 2. Zähle alle Buchungen (Confirmed/Pending, League), für die KEIN Ergebnis vorliegt.

  const leagueResults = resultsData.filter(result => {
    // Wenn wir die Buchung kennen, prüfen wir 'friendly'.
    // Wenn nicht, gehen wir davon aus, dass es ein Ligaspiel ist (oder wir filtern es anderswo).
    if (result.bookingId) {
      const booking = seasonBookings.find(b => b.id === result.bookingId);
      return !booking || !booking.friendly;
    }
    return true; // Ergebnisse ohne Booking-ID zählen als Ligaspiel
  });

  // Relevante Buchungen: Confirmed oder Pending, nicht Friendly, und noch kein Ergebnis
  const relevantBookings = seasonBookings.filter(b =>
    !b.friendly &&
    ['confirmed', 'pending_home_confirm', 'pending_away_confirm'].includes(b.status) &&
    !bookingsWithResults.has(b.id)
  );

  const potentialOpponents = allSeasonTeams.filter(t => t.id !== teamId);

  const opponentList = potentialOpponents.map(opponent => {
    // 1. Anzahl gespielter Ligaspiele (Ergebnisse)
    const gamesPlayed = leagueResults.filter(r =>
      (r.homeTeamId === teamId && r.awayTeamId === opponent.id) ||
      (r.homeTeamId === opponent.id && r.awayTeamId === teamId)
    ).length;

    // 2. Anzahl geplanter/ausstehender Ligaspiele (Buchungen ohne Ergebnis)
    const gamesPlanned = relevantBookings.filter(b =>
      (b.homeTeamId === teamId && b.awayTeamId === opponent.id) ||
      (b.homeTeamId === opponent.id && b.awayTeamId === teamId)
    ).length;

    const totalEncounters = gamesPlayed + gamesPlanned;

    let isEligible = true;
    if (activeSeason.playMode === 'single_round_robin' && totalEncounters >= 1) {
      isEligible = false;
    }
    if (activeSeason.playMode === 'double_round_robin' && totalEncounters >= 2) {
      isEligible = false;
    }

    return {
      ...opponent,
      isEligible,
    };
  });

  // Filtert die Liste serverseitig und gibt NUR die Teams zurück,
  // gegen die noch gespielt werden darf.
  const eligibleOpponents = opponentList.filter(opponent => opponent.isEligible);
  return eligibleOpponents;
}

/**
 * NEU: Berechnet Statistiken für ein Team in einer bestimmten Saison.
 * (Tore/Spiel, Gegentore/Spiel, Punkte/Spiel)
 */
async function getTeamStats(teamId, seasonId) {
  if (!teamId || !seasonId) {
    throw new Error('Team ID und Saison ID sind erforderlich.');
  }

  // Wir holen alle Ergebnisse der Saison und filtern dann im Speicher.
  // Das spart komplexe Indexe und ist bei der zu erwartenden Datenmenge performant genug.
  const snapshot = await resultsCollection
    .where('seasonId', '==', seasonId)
    .where('status', '==', 'confirmed') // Nur bestätigte Ergebnisse zählen
    .get();

  if (snapshot.empty) {
    return {
      gamesPlayed: 0,
      goalsScoredPerGame: 0,
      goalsConcededPerGame: 0,
      pointsPerGame: 0
    };
  }

  let gamesPlayed = 0;
  let totalGoalsScored = 0;
  let totalGoalsConceded = 0;
  let totalPoints = 0;

  snapshot.forEach(doc => {
    const result = doc.data();

    // Ignoriere Freundschaftsspiele
    if (result.friendly) return;

    // Prüfe ob das Team beteiligt war
    if (result.homeTeamId !== teamId && result.awayTeamId !== teamId) return;

    gamesPlayed++;

    const isHome = result.homeTeamId === teamId;
    const myScore = isHome ? result.homeScore : result.awayScore;
    const opponentScore = isHome ? result.awayScore : result.homeScore;

    totalGoalsScored += myScore;
    totalGoalsConceded += opponentScore;

    if (myScore > opponentScore) {
      totalPoints += 3;
    } else if (myScore === opponentScore) {
      totalPoints += 1;
    }
  });

  // Berechnungen und Runden auf 2 Nachkommastellen
  const goalsScoredPerGame = gamesPlayed > 0 ? Number((totalGoalsScored / gamesPlayed).toFixed(2)) : 0;
  const goalsConcededPerGame = gamesPlayed > 0 ? Number((totalGoalsConceded / gamesPlayed).toFixed(2)) : 0;
  const pointsPerGame = gamesPlayed > 0 ? Number((totalPoints / gamesPlayed).toFixed(2)) : 0;

  return {
    gamesPlayed,
    goalsScoredPerGame,
    goalsConcededPerGame,
    pointsPerGame
  };
}

module.exports = {
  createTeam,
  getAllTeams,
  getTeamById,
  updateTeam,
  updateTeamLogo,
  deleteTeam,
  getTeamsByIds,
  getTeamsForSeason,
  getTeamsForActiveSeason,
  getPotentialOpponents,
  getTeamStats, // Neue Funktion exportieren
};
